INSERT INTO tablica1 (name, datetime, colour)
VALUES ('2019-05-01','1');
INSERT INTO tablica1 (name, datetime, colour)
VALUES ('2019-05-02','2');
